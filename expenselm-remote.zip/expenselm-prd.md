# PRD: ExpenseLM — A Fine-Tuned Expense Intelligence Model
### Semester project + post-training learning vehicle + portfolio artifact
**Owner:** Suyash · **Timeline:** 6–8 weeks · **Budget:** ~$0 (Colab free tier + M5 Pro MacBook)

---

## 1. Problem Statement

Businesses receive expense information as unstructured mess: receipt OCR dumps, forwarded emails, chat messages ("paid 450 for cab to airport, client meeting"). Converting this into clean, structured, policy-checked records is currently done either manually or by calling expensive frontier-model APIs on every message.

**Hypothesis:** a small (~4B) open model, fine-tuned on high-quality task-specific data, can match or beat frontier-model zero-shot accuracy on this extraction task at a fraction of the inference cost — and the claim can be *proven* with a rigorous evaluation harness.

This mirrors one of the most common real production patterns in 2026: distilling a narrow capability from frontier models into a cheap, private, self-hosted small model.

## 2. Goals

1. **Learning goal (primary):** experience the complete post-training pipeline hands-on — dataset construction, SFT with LoRA/QLoRA, preference tuning with DPO, quantized export, and evaluation — such that no stage remains abstract.
2. **Artifact goal:** a public GitHub repo + technical writeup with a results table that demonstrates evaluation rigor (the portfolio piece for AI engineering applications).
3. **Academic goal:** a complete, defensible semester project with methodology, experiments, ablations, and analysis.

## 3. Non-Goals (scope fence — violating these is how the project dies)

- No web app, no UI, no deployment infrastructure. A CLI/notebook demo is the finish line.
- No pretraining, no full fine-tuning, no models above ~8B.
- No multi-task model. One task: expense text → structured JSON.
- No integration with the real Reimburse product this semester. (It can inform v2.)
- No perfect dataset. 1,500–2,000 good examples beats 10,000 mediocre ones and beats 6 weeks lost to data generation.

## 4. The Task Specification

**Input:** a raw text string containing expense information. Sources of mess (all must appear in the dataset):
- Chat-style messages, incl. Hinglish ("bhai 450 ka cab liya airport tak, client meeting ke liye")
- Forwarded email bodies with signatures/quoted threads as noise
- Receipt OCR output (broken lines, garbled characters, ALL CAPS)
- Multi-expense messages ("lunch 800, cab back 350")
- Ambiguity: missing currency, relative dates ("yesterday"), unclear reimbursability

**Output:** JSON conforming exactly to this schema:

```json
{
  "expenses": [
    {
      "amount": 450.00,
      "currency": "INR",            // ISO 4217; "UNKNOWN" if not inferable
      "category": "travel",          // enum: travel|meals|lodging|supplies|software|entertainment|other
      "merchant": "string|null",
      "date": "YYYY-MM-DD|null",     // resolved against a reference date given in the prompt
      "description": "short string",
      "reimbursable": true,          // per the policy block provided in the prompt
      "policy_flags": ["missing_receipt", "over_limit", ...]  // possibly empty
    }
  ],
  "confidence": "high|medium|low"
}
```

**System prompt at inference** includes: the schema, a reference date, and a short expense policy (limits per category, what's reimbursable). The model must apply the policy, not just extract — this is what makes the task non-trivial and interesting.

## 5. Dataset Specification

| Split | Size | Purpose |
|---|---|---|
| train | ~1,500 | SFT |
| preference pairs | ~500 pairs | DPO (chosen vs. rejected outputs) |
| dev | 100 | hyperparameter decisions, early-stopping checks |
| test | 200 | **touched exactly once**, for the final table |

**Construction pipeline:**
1. **Seed by hand (Week 1, ~50 examples).** Write these yourself. This step is non-negotiable — it defines the task's edge cases and calibrates your taste before any synthetic generation.
2. **Synthetic generation (Claude/Opus).** Prompt for diversity along explicit axes: source type × language style × ambiguity type × single/multi expense × policy interaction. Generate input + gold output together; generate in batches of 20 with different persona/scenario seeds to avoid mode collapse.
3. **Perturbation pass.** Programmatically inject realism: typos, OCR noise, truncation, currency symbol variants (₹/Rs/INR/rs.).
4. **Human verification.** You review 100% of the test set and dev set, and a 20% random sample of train. Log every correction — the correction log becomes the "data quality" section of your report.
5. **Contamination check.** Ensure no near-duplicates between train and test (embedding similarity or fuzzy string match; reject pairs above threshold).

**DPO pair construction:** for ~500 training inputs, produce a *chosen* (gold) and a *rejected* output. Rejected outputs must be *plausible* failures, not garbage: valid JSON with a wrong category, missed second expense, wrong reimbursability call, hallucinated merchant. Best source: your own SFT model's real mistakes on dev data (run inference, harvest failures) — this makes DPO targeted at actual weaknesses, which is exactly how labs do it.

**Format:** ChatML / the model's native chat template, stored as JSONL. One `messages` array per example.

---

## 6. Tech Stack (verified current, mid-2026)

| Layer | Choice | Why |
|---|---|---|
| Base model | **Qwen3-4B-Instruct** (fallback: Qwen3-1.7B if T4 memory fights you) | Strong small model, day-0 support in Unsloth, good multilingual (helps Hinglish) |
| Method | **QLoRA, rank 16** (4-bit base + LoRA adapters) | The 2026 default; 7B-class QLoRA needs only ~5GB VRAM under Unsloth — trivially fits a T4 |
| SFT + DPO framework | **Unsloth** (Feb 2026 release or later) | 2–5x faster, ~70–80% less VRAM than baseline HF; the undisputed single-GPU choice; free Colab T4 is its home turf |
| Reference implementation | **TRL v1.0** (SFTTrainer, DPOTrainer) | The canonical post-training library. Run ONE small SFT job in raw TRL+PEFT so Unsloth isn't magic to you |
| Compute | Colab free T4 (16GB) for training; **M5 Pro via MLX-LoRA** as local alternative/backup | $0. MLX-LoRA is the 2026-standard way to LoRA-tune on Apple Silicon — worth one run just to have touched it |
| Tracking | Weights & Biases (free tier) | Loss curves for the report; professional habit |
| Eval harness | **Custom Python** (pydantic for schema validation) — deliberately not a framework | Writing the grader yourself IS the learning; ~300 lines |
| Baselines | Claude + GPT via API, zero-shot and few-shot | The bar to beat; a few dollars of API credit total |
| Export & demo | GGUF via llama.cpp → run in LM Studio on your Mac | Closes the loop: your own quantized model chatting locally |

Notes:
- Unsloth free tier is single-GPU only — irrelevant here, you have one GPU.
- Do NOT reach for Axolotl/LLaMA-Factory this project; they solve multi-GPU/production problems you don't have. Knowing *when not* to add tools is part of the skill.

## 7. Experimental Design (this is the semester-project spine)

Systems compared on the identical 200-example test set:

| # | System | What it isolates |
|---|---|---|
| E0 | Qwen3-4B-Instruct, zero-shot (schema in prompt) | Floor: what prompting alone buys |
| E1 | Qwen3-4B-Instruct, 5-shot | Value of in-context examples |
| E2 | E0 + **SFT** | Value of supervised fine-tuning |
| E3 | E2 + **DPO** | Value of preference tuning on top |
| E4 | Frontier model (Claude), zero-shot | The expensive ceiling |
| E5 | E3 quantized to 4-bit GGUF | Cost of quantization on YOUR task |

**Metrics (all computed by your harness):**
1. **Schema validity rate** — parses + validates against pydantic model
2. **Field-level exact match** — per field (amount, currency, category, date, reimbursable), reported separately; amounts within ±0.01
3. **Expense-level F1** — for multi-expense inputs: did it find all expenses, no hallucinated extras (match on amount+category)
4. **Policy accuracy** — reimbursable + policy_flags correctness (the "reasoning" metric)
5. **Cost & latency** — tokens/sec local vs. API $ per 1k messages (the business argument)

**Failure analysis (mandatory, the most valuable section):** for E3, manually categorize every test error into a taxonomy (ambiguous currency, date-resolution failure, category confusion, missed expense, policy misapplication…). This section is what makes the writeup read like eval work rather than a homework.

**Stretch (only if ahead of schedule):** one ablation — vary training set size (250/500/1000/1500) and plot test accuracy vs. data size. A mini scaling-law on your own task; professors and interviewers both love it.

## 8. Milestones

| Week | Deliverable | Definition of done |
|---|---|---|
| 1 | Task spec frozen + 50 hand-written examples + pydantic schema | Schema validates all 50; you can articulate 5 hard edge cases |
| 2 | Full dataset v1 + contamination check | 1,500 train / 100 dev / 200 test in JSONL; verification log started |
| 3 | **Eval harness before any training** + E0/E1/E4 baselines run | One command produces the metrics table for any system |
| 4 | SFT run(s) on Colab (Unsloth) + one raw-TRL mini-run | E2 row filled; W&B loss curves saved; you can explain every hyperparameter you set |
| 5 | Harvest SFT failures → DPO pairs → DPO run | E3 row filled; before/after diff on targeted failure modes |
| 6 | GGUF export + LM Studio demo + E5 row | Model runs locally on your Mac; quantization delta measured |
| 7 | Failure analysis + (stretch) data-size ablation | Error taxonomy with counts and examples |
| 8 | Writeup + repo cleanup + submission | README, report (8–12 pages), reproducible scripts, blog-post version for X/LinkedIn |

Note the deliberate ordering: **the eval harness is built in Week 3, before any training.** Training without evals is flying blind; this ordering is itself one of the lessons.

## 9. Risks & Mitigations

| Risk | Mitigation |
|---|---|
| Colab session death mid-training | Checkpoint to Google Drive every N steps; runs are short (<1–2 hr) by design |
| T4 OOM | Drop to Qwen3-1.7B; shrink batch to 1–2 + gradient accumulation; shorten max_seq_len |
| Synthetic data too clean/samey | Perturbation pass + explicit diversity axes + hand-written seeds anchoring the distribution |
| DPO degrades the model (common!) | Small beta first, few epochs, always compare E3 vs E2 on dev before believing anything |
| Dataset perfectionism eats the semester | Hard cap: Week 2 ends data v1. Improvements only if evals expose specific gaps |
| "It works" without understanding | AI-usage protocol below |

## 10. AI-Usage Protocol (how to build with Opus and still own the knowledge)

You'll build this with Claude's help. That's realistic and fine — but under rules, or you'll finish with a repo you can't defend in a viva:

1. **Write yourself, no AI:** the 50 seed examples, the pydantic schema, and the eval harness's grading logic. These three ARE the project's brain.
2. **AI writes, you interrogate:** training scripts, data-generation pipelines, plotting code. Rule: after Claude writes a file, you explain every non-obvious line back to Claude and ask it to challenge your explanation. If you can't explain a line, it doesn't get committed.
3. **The flashcard test:** at each milestone, write (yourself, from memory) a half-page "what I now understand that I didn't before." Eight of these = the core of your report's learning section + your viva prep.
4. **Debug before delegating:** when a run fails, form your own hypothesis first, THEN ask Claude. The hypothesis habit is the skill.

## 11. Final Deliverables

1. GitHub repo (`blinderchief/expenselm` or similar): data pipeline, training scripts, eval harness, README with the results table front and center
2. Semester report (8–12 pp): problem, related work (SFT/LoRA/DPO — cite the papers you've already got), methodology, experiments E0–E5, failure analysis, learnings
3. Model artifacts: LoRA adapters + GGUF on HuggingFace Hub
4. Public writeup (blog/X thread): "I fine-tuned a 4B model to beat frontier-model pricing on expense extraction — here's the eval"
5. The answer to your real question: 8 weeks of honest data on whether this work pulls you in

---

*Success looks like: one table, six rows, five metrics, no vibes.*
